-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 06:23 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_kendaraan`
--

CREATE TABLE `tb_kendaraan` (
  `id_kendaraan` int(11) NOT NULL,
  `nama_kendaraan` varchar(255) NOT NULL,
  `jml_kursi` int(11) NOT NULL,
  `jml_kursi_tersedia` int(11) NOT NULL,
  `transmisi` varchar(50) NOT NULL,
  `tahun` varchar(50) NOT NULL,
  `plat_nomor` varchar(20) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kendaraan`
--

INSERT INTO `tb_kendaraan` (`id_kendaraan`, `nama_kendaraan`, `jml_kursi`, `jml_kursi_tersedia`, `transmisi`, `tahun`, `plat_nomor`, `deskripsi`, `foto`, `thumbnail`) VALUES
(1, 'Toyota Yaris', 4, 4, 'Manual', '2011', 'BA 3180 PG', 'Dengan peringkat penghematan bahan bakar yang sangat baik dan, banyak fitur keselamatan standar, Toyota Yaris 2011 adalah pilihan cerdas bagi penyewa yang menginginkan mobil komuter kecil, meskipun beberapa saingan menawarkan lebih banyak penyempurnaan interior dan skor keamanan yang lebih baik. Toyota Yaris nyaman dibawa berpergian jauh atau dekat', 'yaris.jpg', 'tb_yaris.png'),
(2, 'Nissan Juke', 4, 4, 'Manual', '2017', 'BA 4989 PT', 'Nissan Juke 2015 ini memiliki mesin zippy dan penanganan yang sporty dan dinamis. Penghematan bahan bakar yang bagus jika menggunakan bensin premium. SUV crossover ini adalah mesin empat silinder 1,6 liter turbocharged yang menghasilkan 188 tenaga kuda dan torsi 177 pon-kaki. Di Nismo RS, mesin ini mengeluarkan 215 tenaga kuda dengan penggerak roda depan dan transmisi manual enam percepatan, atau 211 tenaga kuda dengan penggerak semua roda dan transmisi otomatis (CVT) yang terus-menerus bervariasi.?', 'nissan.jpg', 'tb_nissan.png'),
(3, 'Honda Brio', 4, 4, 'Manual', '2018', 'BA 2906 PA', 'Pilihan trendy dan stylish untuk have fun bareng sama teman atau keluarga.\r\nAll New Honda Brio RS untuk kamu yang suka dengan sensasi berkendara bergaya sporty dan lebih seru.Perjalanan lebih menyenangkan dengan interior two tone color dan ruang kabin yang luas sehingga memberikan kenyamanan ekstra untuk pengemudi dan penumpang.All New Honda Brio dilengkapi dengan fitur keselamatan yang baik sehingga memberikan rasa lebih aman dalam berkendara.', 'brio.jpg', 'tb_brio.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `foto_profil` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id_pelanggan`, `nama_pelanggan`, `jenis_kelamin`, `no_hp`, `foto_profil`, `username`, `password`, `token`) VALUES
(1, 'test', 'betina', '123456789', '', 'test', 'test', ''),
(4, 'hidayatul', 'Laki-Laki', '08123434', 'PasFotoMufidatulIsnainiHafizahFix.jpg', 'fadil', '$2y$10$GrXf9wNIJRBXyT05lZV5JuV2cCua3pJRaGQkMNRjaanJONpM7Qn.y', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2RiX3RyYXZlbFwvIiwiYXVkIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9kYl90cmF2ZWxcLyIsImlzc3VlZEF0IjoxNjIyODc2MjE5LCJleHBpcmUiOjE2MjI4ODM0MTksImRhdGEiOnsidXNlcl9pZCI6IjQifX0.hTjy4r9tDCO2pR_dUtYLs5'),
(5, 'hasan', 'Laki-Laki', '123456789', 'jpg_20210609_114558-1230886045.jpg', 'hasan', '$2y$10$EC6N8hhlCSxsCbt5gkzpouzOrcLksc8qBKPfAbPHeXYm7REj3HKNa', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2RiX3RyYXZlbFwvIiwiYXVkIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9kYl90cmF2ZWxcLyIsImlzc3VlZEF0IjoxNjIzMjEyOTk0LCJleHBpcmUiOjE2MjMyMjAxOTQsImRhdGEiOnsidXNlcl9pZCI6IjUifX0.lA_lf-JwcXHhKFlngcKWqz'),
(7, 'harta', 'Perempuan', '0987654321', 'jpg_20210609_121821-1081007813.jpg', 'tahta', '$2y$10$WicMIM/HNhmZ4gpJ7Y2w9ukBe5xh9leCvIBNhGLaeFKp/Iv72BeZy', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2RiX3RyYXZlbFwvIiwiYXVkIjoiaHR0cDpcL1wvbG9jYWxob3N0XC9kYl90cmF2ZWxcLyIsImlzc3VlZEF0IjoxNjIzMjE2MTMwLCJleHBpcmUiOjE2MjMyMjMzMzAsImRhdGEiOnsidXNlcl9pZCI6IjcifX0.yw4YFdUvxFTAF_p8kSKTKr');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pemesanan`
--

CREATE TABLE `tb_pemesanan` (
  `id_pemesanan` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `id_rute` int(11) NOT NULL,
  `id_kendaraan` int(11) NOT NULL,
  `tgl_pergi` date NOT NULL,
  `jml_pesan` int(11) NOT NULL,
  `jml_bayar` int(11) NOT NULL,
  `bukti_pembayaran` varchar(255) NOT NULL,
  `status_pembayaran` tinyint(4) NOT NULL,
  `invoice_pemesanan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pemesanan`
--

INSERT INTO `tb_pemesanan` (`id_pemesanan`, `id_pelanggan`, `id_rute`, `id_kendaraan`, `tgl_pergi`, `jml_pesan`, `jml_bayar`, `bukti_pembayaran`, `status_pembayaran`, `invoice_pemesanan`) VALUES
(1, 4, 2, 2, '2021-05-07', 2, 240000, 'PasFotoMufidatulIsnainiHafizahFix.jpg', 1, ''),
(2, 4, 1, 1, '2021-05-01', 1, 210000, 'CamScanner09-19-202021.55.54_1.jpg', 0, ''),
(17, 4, 1, 3, '2021-05-28', 6, 63000, 'MBRC_1602829039054.png', 0, ''),
(19, 2, 2, 3, '2021-06-20', 1, 0, 'MBRC_1602949874149.png', 0, ''),
(22, 2, 1, 2, '2021-06-04', 3, 42000, 'LOGO.jpg', 0, ''),
(23, 5, 2, 1, '2021-06-04', 3, 24000, 'MBRC_1602829039054.png', 1, ''),
(29, 5, 4, 1, '2021-06-06', 4, 180000, 'accpakhidra.jpg', 0, ''),
(31, 5, 1, 1, '2021-06-07', 3, 63000, '20210109_214756.jpg', 0, ''),
(33, 7, 3, 2, '2021-06-20', 2, 800000, 'Screenshot_20210529-110002.png', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_perjalanan`
--

CREATE TABLE `tb_perjalanan` (
  `id_perjalanan` int(11) NOT NULL,
  `id_rute` int(11) NOT NULL,
  `id_kendaraan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_perjalanan`
--

INSERT INTO `tb_perjalanan` (`id_perjalanan`, `id_rute`, `id_kendaraan`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 2, 1),
(5, 2, 2),
(6, 2, 3),
(7, 3, 2),
(8, 4, 1),
(9, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_rute`
--

CREATE TABLE `tb_rute` (
  `id_rute` int(11) NOT NULL,
  `rute_awal` varchar(255) NOT NULL,
  `rute_tujuan` varchar(255) NOT NULL,
  `tarif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_rute`
--

INSERT INTO `tb_rute` (`id_rute`, `rute_awal`, `rute_tujuan`, `tarif`) VALUES
(1, 'Solok', 'Padang', 21000),
(2, 'Solok', 'Bukittinggi', 24000),
(3, 'Solok', 'Medan', 400000),
(4, 'Solok', 'Payakumbuh', 45000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_kendaraan`
--
ALTER TABLE `tb_kendaraan`
  ADD PRIMARY KEY (`id_kendaraan`);

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `tb_pemesanan`
--
ALTER TABLE `tb_pemesanan`
  ADD PRIMARY KEY (`id_pemesanan`);

--
-- Indexes for table `tb_perjalanan`
--
ALTER TABLE `tb_perjalanan`
  ADD PRIMARY KEY (`id_perjalanan`);

--
-- Indexes for table `tb_rute`
--
ALTER TABLE `tb_rute`
  ADD PRIMARY KEY (`id_rute`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_kendaraan`
--
ALTER TABLE `tb_kendaraan`
  MODIFY `id_kendaraan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_pemesanan`
--
ALTER TABLE `tb_pemesanan`
  MODIFY `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tb_perjalanan`
--
ALTER TABLE `tb_perjalanan`
  MODIFY `id_perjalanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_rute`
--
ALTER TABLE `tb_rute`
  MODIFY `id_rute` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
