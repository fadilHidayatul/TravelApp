<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['id_user']) || empty(trim($_POST['id_user']))
) {
    $returnData = msg(0,400,'Id user tidak ada');
}else {
    $idUser = $_POST['id_user'];

    if (empty($_FILES)) {
        $returnData = msg(0,204,'Gambar tidak ada');
    }else {

        $ext_allow = array('png','jpg');
        $img_profil = $_FILES['fotoprofil']['name'];
        $temp_profil = $_FILES['fotoprofil']['tmp_name'];
        $x = explode('.', $img_profil);
        $ext = strtolower(end($x));

        $fix_profil = str_replace(" ", "", $img_profil);

        if (in_array($ext, $ext_allow) === true ) {
            move_uploaded_file($temp_profil, '../img/profil/'.$fix_profil);

            $query = "UPDATE tb_pelanggan SET foto_profil = :profil
                    WHERE id_pelanggan = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(":profil", $fix_profil);
            $stmt->bindParam(":id", $idUser);
            $stmt->execute();

            $returnData = msg(1,200, 'Update foto profil berhasil');
        }else {
            $returnData = msg(0,300, 'Ekstensi foto tidak sesuai, masukkan jpg atau png');
        }

    }


}
echo json_encode($returnData);
?>