<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['id_user']) || empty(trim($_POST['id_user']))
) {
    $returnData = msg(0,400,'Id user tidak ada');
}else {
    $id_user = trim($_POST['id_user']);

    $query = "SELECT foto_profil FROM tb_pelanggan WHERE id_pelanggan = :idpel";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":idpel", $id_user);
    $stmt->execute();

    if ($stmt->rowCount()) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $returnData = [
            'status' => '200',
            'message' => 'Foto Profil Ada',
            'data' => array(
                'foto_profil' => $row['foto_profil']
            )
            ];
    }else {
        $returnData = msg(0,400,'Foto Tidak Ada');
    }
}

echo json_encode($returnData);
?>