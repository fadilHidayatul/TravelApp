<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['username']) || !isset($_POST['password']) || empty(trim($_POST['username'])) || empty(trim($_POST['password']))
) {
    $returnData = msg(0,400,'Harap Isi Semua Field');
}else {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    try{
        $get_user = "SELECT * FROM tb_pelanggan WHERE username = :username";
        $statement = $conn->prepare($get_user);
        $statement->bindParam(":username", $username);
        $statement->execute();

        if ($statement->rowCount()) {
            $row = $statement->fetch(PDO::FETCH_ASSOC);
            $chk_pass = password_verify($password, $row['password']);

            if ($chk_pass) {
                $jwt = new jwtHandler();
                $token = $jwt->_jwt_encode_data(
                    'http://localhost/db_travel/',
                    array("user_id" => $row['id_pelanggan'])
                );

                $query = "UPDATE tb_pelanggan SET token = :token WHERE username = :username";
                $update = $conn->prepare($query);
                $update->bindParam(":token", $token);
                $update->bindParam(":username", $username);
                $update->execute();

                $returnData = [
                    'status' => 200,
                    'message' => 'Success Login',
                    'data' => array(
                        'id_pelanggan' => $row['id_pelanggan'],
                        'username' => $row['username'],
                        'nama' => $row['nama_pelanggan'],
                        'jenis_kelamin' => $row['jenis_kelamin'],
                        'no_hp' => $row['no_hp'],
                        'token' => $token
                    )
                    ];


            }else {
                $returnData = msg(0,412,'Password Salah');
            }
        }else {
            $returnData = msg(0,412,'Anda Belum Mendaftar');
        }


    }catch(PDOException $e){
        $returnData = msg(0,500,$e->getMessage());
    }
}

echo json_encode($returnData);
?>