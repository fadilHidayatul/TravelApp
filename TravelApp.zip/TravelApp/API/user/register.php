<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];


if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['nama']) || !isset($_POST['jekel']) || !isset($_POST['hp']) || !isset($_POST['username']) || !isset($_POST['password']) ||
    empty(trim($_POST['nama'])) || empty(trim($_POST['jekel'])) || empty(trim($_POST['hp'])) || empty(trim($_POST['username'])) || empty(trim($_POST['password']))
) {
    $returnData = msg(0,400, 'Harap Isi Semua Field');
}else {
    $nama = trim($_POST['nama']);
    $jk = trim($_POST['jekel']);
    $hp = trim( $_POST['hp']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $token = "";

    if(strlen($password) < 4){
        $returnData = msg(0,411,'Password minimal 4 karakter');
    }else {
        try{
        $stringpass = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO tb_pelanggan(nama_pelanggan,jenis_kelamin,no_hp,username,password,token)
                    VALUES(:nama,:jk,:hp,:username,:pwd,:token)";

        $stmt = $conn->prepare($query);
        $stmt->bindParam(":nama", $nama);
        $stmt->bindParam(":jk", $jk);
        $stmt->bindParam(":hp", $hp);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":pwd", $stringpass);
        $stmt->bindParam(":token", $token);
        $stmt->execute();

        $returnData = msg(1,200,'Register Berhasil');

        }catch(PDOException $e){
            $returnData = msg(0,500,$e->getMessage());
        }
    }
}

echo json_encode($returnData);
?>