<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['rute']) || !isset($_POST['mobil']) || !isset($_POST['jumlah_kursi']) || !isset($_POST['tgl_from']) ||
    empty(trim($_POST['rute'])) || empty(trim($_POST['mobil'])) || empty(trim($_POST['jumlah_kursi'])) || empty(trim($_POST['tgl_from']))
) {
    $returnData = msg(0,400,'Harap Input Semua Data');
}else {
    $id_pel = trim($_POST['pelanggan']);
    $id_rute = trim($_POST['rute']);
    $id_kendaraan = trim($_POST['mobil']);
    $tgl_pergi = trim($_POST['tgl_from']);
    $jml_pesan = trim($_POST['jumlah_kursi']);
    $bukti = "";
    $status = "0";
    $invoice = "";

    $get_rute = "SELECT * FROM tb_rute WHERE id_rute = :idrute";
    $trf = $conn->prepare($get_rute);
    $trf->bindParam(":idrute", $id_rute);
    $trf->execute();
    $row_trf = $trf->fetch(PDO::FETCH_ASSOC);

    $tarif = $row_trf['tarif'] * $jml_pesan;

    $query = "INSERT INTO tb_pemesanan(id_pelanggan,id_rute,id_kendaraan,tgl_pergi,jml_pesan,jml_bayar,bukti_pembayaran,status_pembayaran,invoice_pemesanan)
            VALUES(:idpel,:idrute,:idkendaraan,:tglfrom,:amount,:price,:bukti,:stat,:invoice)";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(":idpel", $id_pel);
    $stmt->bindParam(":idrute", $id_rute);
    $stmt->bindParam(":idkendaraan", $id_kendaraan);
    $stmt->bindParam(":tglfrom", $tgl_pergi);
    $stmt->bindParam(":amount", $jml_pesan);
    $stmt->bindParam(":price", $tarif);
    $stmt->bindParam(":bukti", $bukti);
    $stmt->bindParam(":stat", $status);
    $stmt->bindParam(":invoice", $invoice);
    $stmt->execute();

    $returnData = msg(1,200,'Pemesanan Anda Berhasil');
    
}

echo json_encode($returnData);
?>