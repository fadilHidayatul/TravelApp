<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
     empty($_POST['idpesan']) ||
      !isset($_POST['idpesan'])
) {
    $returnData = msg(0,400,'Id Pemesanan Tidak Ada');
}else {
    $idpesan = trim($_POST['idpesan']);

    $query = "DELETE FROM tb_pemesanan WHERE id_pemesanan = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id", $idpesan);
    $stmt->execute();

    $returnData = msg(1,200,'Hapus Pesanan Berhasil');
}

echo json_encode($returnData);
?>