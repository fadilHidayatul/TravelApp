<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['id_pemesanan']) || empty(trim($_POST['id_pemesanan']))
) {
    $returnData = msg(0,400,'Id Pemesanan Tidak Ada');
}else {
    $id_pesanan = trim($_POST['id_pemesanan']);

    $count = count($_FILES['upload_bukti']['name']);

    for ($i=0; $i < $count; $i++) { 
        $img_array = $_FILES['upload_bukti']['name'][$i];
        $tmp_array = $_FILES['upload_bukti']['tmp_name'][$i];

        $ext_allow = array('png','jpg');
        $x = explode('.', $img_array);
        $ext = strtolower(end($x));

        $image_name = str_replace(" ", "", $img_array);
        

        if (in_array($ext, $ext_allow) === true) {
            move_uploaded_file($tmp_array, '../img/tf/'.$image_name);

            $query = "UPDATE tb_pemesanan SET bukti_pembayaran = :bukti
                      WHERE id_pemesanan = :idpes";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(":bukti", $image_name);
            $stmt->bindParam(":idpes", $id_pesanan);
            $stmt->execute();

            $returnData = msg(1,200, 'Update Pembayaran Berhasil');
        }else {
            $returnData = msg(0,300, 'Ekstensi foto ada yang tidak sesuai, masukkan jpg atau png');
        }

    }


}

echo json_encode($returnData);
?>
