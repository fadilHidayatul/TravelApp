<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "GET") {
    $returnData = msg(0,405,'Method Not Allowed');
}else {
    $query = "SELECT * FROM tb_kendaraan ORDER BY nama_kendaraan ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id_kendaraan" => $row['id_kendaraan'],
                "nama_kendaraan" => $row['nama_kendaraan'],
                "kursi" => $row['jml_kursi'],
                "kursi_tersedia" => $row['jml_kursi_tersedia'],
                "transmisi" => $row['transmisi'],
                "tahun" => $row['tahun'],
                "plat" => $row['plat_nomor'],
                "deskripsi" => $row['deskripsi'],
                "foto" => $row['foto'],
                "thumbnail" => $row['thumbnail']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data ada', $data);
    }else {
        $returnData = msg(0,204,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>