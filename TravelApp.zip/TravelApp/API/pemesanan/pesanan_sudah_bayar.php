<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['id_pelanggan']) || empty(trim($_POST['id_pelanggan']))
) {
    $returnData = msg(0,400,'Id Pelanggan Tidak Ditemukan');
}else {
    $idPelanggan = trim($_POST['id_pelanggan']);

    $query = "SELECT p.*, r.*, k.* FROM tb_pemesanan p
            LEFT JOIN tb_rute r ON p.id_rute = r.id_rute
            LEFT JOIN tb_kendaraan k ON p.id_kendaraan = k.id_kendaraan
            WHERE p.id_pelanggan = :id AND p.status_pembayaran = 1
            ORDER BY p.tgl_pergi ASC";

    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id", $idPelanggan);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id_pemesanan" => $row['id_pemesanan'],
                "id_pelanggan" => $row['id_pelanggan'],
                "rute_awal" => $row['rute_awal'],
                "rute_tujuan" => $row['rute_tujuan'],
                "mobil" => $row['nama_kendaraan'],
                "tgl_pergi" => $row['tgl_pergi'],
                "jml_pesan" => $row['jml_pesan'],
                "tarif" => $row['jml_bayar'],
                "invoice" => $row['invoice_pemesanan']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(0,200,'Data ada', $data);
    }else {
        $returnData = msg(0,204,'Data tidak ada');
    }
}

echo json_encode($returnData);
?>