<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message'=> $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->dbConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,405,'Method Not Allowed');
}elseif (
    !isset($_POST['id_rute']) || empty(trim($_POST['id_rute']))
) {
    $returnData = msg(0,400,'Id Rute Tidak Ada');
}else {
    $idRute = $_POST['id_rute'];

    $query = "SELECT p.*, k.* FROM tb_perjalanan p
            LEFT JOIN tb_kendaraan k ON p.id_kendaraan = k.id_kendaraan
            WHERE id_rute = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(":id", $idRute);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $data["DATA"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $item = array(
                "id_kendaraan" => $row['id_kendaraan'],
                "nama_kendaraan" => $row['nama_kendaraan'],
                "kapasitas" => $row['jml_kursi_tersedia']
            );
            array_push($data["DATA"], $item);
        }

        $returnData = msg(1,200,'Data Ada', $data);
    }else {
        $returnData = msg(0,204,'Data Tidak Ada');
    }
}

echo json_encode($returnData);
?>